It returns the attachment from the root folder
[[cat.jpeg]]

