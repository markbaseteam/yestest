# 🎧 Summary of All-In Podcast Episode 95
## ⚡️ Europe's Winter Energy Crisis
- Russia has cut off natural gas supplies to Europe as a result of the Russia-Ukraine conflict. The result:
	- The price of gas has become 10 times higher than the average cost of the past 10 years (Source: [Goldman Sachs Report](https://www.goldmansachs.com/insights/pages/europe-energy-crisis-is-at-a-tipping-point.html))
	- Cost of food and heating homes has increased
	- This could cascade into the buying power of European currencies to diminish, costs to import goods and services to inflate, and economies being negatively impacted
- Many European leaders are still determined to stand up against Russia, but a compromise may need to be negotiated if the war further worsens the lives of their own citizens

## 💰 Kim Kardashian launches her own private equity firm
- Her firm SKKY Partners will invest in consumer and media businesses. 
- The rise of influencers, creators and individuals as a predictor of the firm's success:
	- Distribution is the number one problem for all consumer goods and services. Costs of advertising on social media has increased significantly resulting in worse unit economics for direct-to-consumer (DTC) businesses. Content marketing has become an essential marketing strategy as influencers can directly distribute goods to their audience at little cost.
	- Every company needs to create content to differentiate themselves.

![[🤓 Reading Diary/Podcasts/Attachments/dog.png]]



Post path: Reading Diary/Podcasts/Summary.md
Image file name: cat:Attachments:Podcasts:Reading Diary.jpeg
First token: Image name
Second token: Attachments folder

Check in current directory and all its children, otherwise look in root directory.

i.e. look in Reading Diary/Podcasts and all its subdirectories.
DFS/BFS.
It is BFS because if you have an image with the same name in the current directory and a child directory, the current directory takes precedence.

If doesn't exist, look in root directory.

ImageDirectory Tree
Store subdirectories and all the images. Image name mapped to generated name (to handle images of same name in different places)
E.G. key would be "Reading Diary/Podcasts".

Wrong..
We can access images from other subfolders still.. e.g. More/bird2 from this file.


How to process image:

Ways we could get to this image:
cat.jpeg // We can check if there is any in the current directory, or in any of the children directories. If it isn't, look in root directory.
Nested/cat.jpeg // We can check if t
Attachments/Nested/cat.jpeg // We can check this subfolder. If not, look in root directory.
Podcasts/Attachments/cat.jpeg // We can check this subfolder, if not look in root directory.
Reading Diary/Podcasts/Attachments/cat.jpeg // We can check this subfolder, if not, look in root directory.
![[Attachments/cat.jpeg]]

![[🤓 Reading Diary/Attachments/More/bird2.jpeg]]

![[bird.jpeg]]

![[bird2.jpeg]]